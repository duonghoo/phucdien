<?php
  
return [
  
    'title' => 'Tiếng việt',
    'add' => 'Thêm vào giỏ hàng'
];