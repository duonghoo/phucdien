<?php
  
return [
  
    'title' => 'English',
    'add' => 'Add to cart',
    'home' => 'Home',
    'preview' => 'About us',
    'recruit' => 'Recruit',
    'contact' => 'Contact',
    'product' => 'Product'
    
  
];