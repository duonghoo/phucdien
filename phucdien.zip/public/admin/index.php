<?php
header('location: /admin/login');
?>
