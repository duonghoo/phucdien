<?php

namespace App\Traits;

trait Test
{

	

}